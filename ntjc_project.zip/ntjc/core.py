def main():
    print("✅ 실행 성공: Hello from ntjc.core.main()")
