class MyClass:
    def greet(self):
        print("Hello from package.myclass!")
